# 聊天会话页面

## 状态

- **状态**: 进行中
- **创建时间**: 2025-10-27
- **最后更新**: 2025-10-27

## 前置条件

- ✅ API 层已生成：`src/services/api/sessions/sessions.ts` 和 `src/services/api/messages/messages.ts`
- ✅ API 类型已生成：所有会话和消息相关的类型定义已存在于 `src/types/api/`
- ✅ 基础项目结构已就绪：路由、状态管理、UI 框架等基础设施已配置

## 任务列表

### 1. 项目基础设施搭建

#### 1.1 创建聊天页面目录结构

- [x] 任务完成

**描述**: 创建聊天功能所需的目录结构

**子任务**:

- 创建 `src/pages/chat/` 目录
- 创建 `src/pages/chat/components/` 子目录
- 创建 `src/hooks/chat/` 目录用于聊天相关 hooks
- 创建 `src/types/chat.ts` 用于聊天类型定义

**验收标准**:

- 所有目录已创建
- 目录结构符合项目规范

---

#### 1.2 配置路由

- [ ] 任务完成

**描述**: 配置聊天页面路由和菜单

**子任务**:

- 在 `src/router.tsx` 中添加 `/chat` 路由到 resources 数组
- 配置路由支持 `?sessionId=xxx` 查询参数
- 在资源配置中添加聊天菜单项（图标使用 MessageOutlined）
- 创建 `src/pages/chat/index.tsx` 页面组件

**验收标准**:

- 可以通过 `/chat` 访问聊天页面
- 支持 sessionId 查询参数
- 菜单中显示聊天入口

---

#### 1.3 创建聊天状态管理 Store

- [ ] 任务完成

**描述**: 创建聊天功能的全局状态管理

**子任务**:

- 创建 `src/stores/chatStore.ts`
- 定义 ChatStore 接口（包含当前会话、消息列表、用户输入、生成状态等）
- 实现 Zustand store 的基本结构
- 在 `src/stores/index.ts` 中导出 chatStore

**验收标准**:

- Store 可以正常导入使用
- 状态定义完整且类型安全

---

#### 1.4 定义聊天类型

- [ ] 任务完成

**描述**: 定义聊天功能所需的 TypeScript 类型

**子任务**:

- 在 `src/types/chat.ts` 中定义本地使用的类型
- 创建类型映射函数，将 API 类型（SessionResponse, MessageDetailResponse）转换为本地类型
- 定义 ChatSettings、StreamingState 等辅助类型

**验收标准**:

- 类型定义完整且符合 TypeScript 严格模式
- 类型映射函数正确转换 API 类型

---

### 2. 会话列表功能实现

#### 2.1 创建 SessionList 组件

- [ ] 任务完成

**描述**: 创建会话列表组件

**子任务**:

- 创建 `src/pages/chat/components/SessionList/index.tsx`
- 实现会话列表的基本布局（固定宽度 280px，可折叠）
- 添加新建会话按钮（使用 Ant Design Button + PlusOutlined 图标）
- 添加搜索输入框（使用 Ant Design Input.Search）
- 创建对应的 CSS Module 文件 `index.module.css`
- 使用 Flexbox 布局：顶部操作区 + 滚动列表区

**验收标准**:

- 会话列表布局正确
- 新建会话按钮可点击
- 搜索框可输入

---

#### 2.2 创建 SessionItem 组件

- [ ] 任务完成

**描述**: 创建会话项组件

**子任务**:

- 创建 `src/pages/chat/components/SessionItem/index.tsx`
- 实现会话项的显示（标题、最后消息预览、时间戳）
- 添加选中状态样式（使用 teal 主题色 #14b8a6）
- 实现悬停显示操作按钮（置顶、归档、删除）
- 显示置顶图标（PushpinOutlined）和归档状态
- 创建对应的 CSS Module 文件 `index.module.css`

**验收标准**:

- 会话项显示完整信息
- 选中状态样式正确
- 悬停显示操作按钮

---

#### 2.3 实现会话列表数据加载

- [ ] 任务完成

**描述**: 实现会话列表数据获取

**子任务**:

- 在 SessionList 组件中使用 React Query 的 useQuery
- 调用 `getSessions().getChatSessions({ page: 1, pageSize: 50, archived: false })` API
- 实现加载状态显示（使用 Ant Design Spin 组件）
- 实现错误处理（使用 Ant Design message 显示错误提示）
- 实现自动重试机制（React Query 默认重试 3 次）

**验收标准**:

- 会话列表正确加载
- 加载状态显示正确
- 错误处理完善

---

#### 2.4 实现会话操作功能

- [ ] 任务完成

**描述**: 实现会话的增删改查操作

**子任务**:

- 创建 `src/hooks/chat/useSessionOperations.ts` hook
- 实现新建会话功能（调用 `postChatSessions` API，使用 useMutation）
- 实现置顶会话功能（调用 `postChatSessionsIdPin` API）
- 实现归档会话功能（调用 `postChatSessionsIdArchive` API）
- 实现删除会话功能（调用 `deleteChatSessionsId` API，带确认对话框）
- 操作成功后刷新会话列表（使用 queryClient.invalidateQueries）

**验收标准**:

- 所有操作功能正常
- 操作后列表自动刷新
- 删除前有确认提示

---

#### 2.5 实现会话搜索功能

- [ ] 任务完成

**描述**: 实现会话搜索功能

**子任务**:

- 在 SessionList 组件中添加搜索状态管理
- 实现搜索防抖（使用 lodash.debounce 或自定义 hook，延迟 300ms）
- 调用 `getChatSessionsSearch({ keyword, page: 1, pageSize: 20 })` API
- 显示搜索结果（替换当前列表）
- 清空搜索时恢复原列表

**验收标准**:

- 搜索功能正常
- 防抖生效
- 搜索结果正确显示

---

### 3. 聊天界面核心组件

#### 3.1 创建 ChatPage 主页面

- [ ] 任务完成

**描述**: 创建聊天主页面

**子任务**:

- 在 `src/pages/chat/index.tsx` 中实现主页面组件
- 实现左右分栏布局（使用 Ant Design Layout 或 Flexbox）
- 从 URL query 参数获取 sessionId（使用 useSearchParams）
- 处理无 sessionId 的情况（显示欢迎页面或空状态）
- 实现响应式布局（屏幕 < 768px 时左侧栏收起为 Drawer）
- 管理侧边栏折叠状态（保存到 localStorage）

**验收标准**:

- 页面布局正确
- URL 参数解析正常
- 响应式布局生效

---

#### 3.2 创建 ChatUI 组件

- [ ] 任务完成

**描述**: 创建聊天界面组件

**子任务**:

- 创建 `src/pages/chat/components/ChatUI/index.tsx`
- 实现聊天界面的整体布局（ChatHeader + ChatMessages + ChatInput）
- 使用 Flexbox 布局：header 固定高度，messages 自动填充，input 固定底部
- 处理无会话时的空状态显示
- 创建对应的 CSS Module 文件 `index.module.css`

**验收标准**:

- 聊天界面布局正确
- 空状态显示正常

---

#### 3.3 创建 ChatHeader 组件

- [ ] 任务完成

**描述**: 创建聊天头部组件

**子任务**:

- 创建 `src/pages/chat/components/ChatHeader/index.tsx`
- 显示会话标题（使用 Typography.Title，支持长标题省略）
- 添加折叠侧边栏按钮（MenuFoldOutlined/MenuUnfoldOutlined）
- 添加设置按钮（SettingOutlined，打开设置 Drawer）
- 应用 teal 主题色（#14b8a6）到标题区域
- 创建对应的 CSS Module 文件 `index.module.css`

**验收标准**:

- 标题显示正确
- 按钮功能正常
- 主题色应用正确

---

### 4. 消息展示功能

#### 4.1 创建 ChatMessages 组件

- [ ] 任务完成

**描述**: 创建消息列表组件

**子任务**:

- 创建 `src/pages/chat/components/ChatMessages/index.tsx`
- 实现消息列表的滚动容器（使用 overflow-y: auto）
- 按时间顺序展示消息（从上到下）
- 实现消息分组（相隔 > 5 分钟显示时间戳分隔符）
- 使用 useRef 管理滚动容器引用
- 创建对应的 CSS Module 文件 `index.module.css`

**验收标准**:

- 消息列表滚动正常
- 消息分组显示正确

---

#### 4.2 创建 Message 组件

- [ ] 任务完成

**描述**: 创建单条消息组件

**子任务**:

- 创建 `src/pages/chat/components/Message/index.tsx`
- 区分用户消息和 AI 消息的样式（根据 role 字段）
- 用户消息：teal 背景（#14b8a6），白色文字，右对齐
- AI 消息：灰色背景（#f3f4f6），黑色文字，左对齐
- 添加头像显示（使用 Ant Design Avatar，用户显示 UserOutlined，AI 显示 RobotOutlined）
- 悬停显示操作按钮（编辑、删除、复制，使用 Tooltip）
- 创建对应的 CSS Module 文件 `index.module.css`

**验收标准**:

- 消息样式正确
- 操作按钮显示正常

---

#### 4.3 集成 Markdown 渲染

- [ ] 任务完成

**描述**: 集成 Markdown 渲染功能

**子任务**:

- 安装依赖：`yarn add react-markdown remark-gfm rehype-highlight`
- 创建 `src/pages/chat/components/MessageMarkdown/index.tsx`
- 配置 react-markdown 的安全选项（禁用 HTML 标签）
- 支持 GitHub Flavored Markdown（表格、删除线等）
- 自定义渲染器适配 Ant Design 样式（链接、列表等）
- 代码块使用 MessageCodeBlock 组件渲染

**验收标准**:

- Markdown 渲染正确
- 安全选项生效

---

#### 4.4 创建 MessageCodeBlock 组件

- [ ] 任务完成

**描述**: 创建代码块组件

**子任务**:

- 创建 `src/pages/chat/components/MessageCodeBlock/index.tsx`
- 安装 highlight.js：`yarn add highlight.js @types/highlight.js`
- 使用 highlight.js 进行语法高亮
- 显示语言标签（在代码块顶部）
- 添加一键复制按钮（使用 Ant Design Button + CopyOutlined）
- 支持代码折叠（行数 > 20 时显示展开/收起按钮）
- 创建对应的 CSS Module 文件 `index.module.css`

**验收标准**:

- 代码高亮正常
- 复制功能正常
- 折叠功能正常

---

#### 4.5 实现消息数据加载

- [ ] 任务完成

**描述**: 实现消息数据获取

**子任务**:

- 在 ChatUI 组件中使用 React Query 的 useQuery
- 调用 `getMessages().getChatSessionsIdMessages({ id: sessionId }, { page: 1, pageSize: 50 })` API
- 实现加载状态显示（在消息列表顶部显示 Spin）
- 实现向上滚动加载更多（使用 IntersectionObserver 监听顶部元素）
- 处理加载错误（使用 Ant Design message 显示错误提示）

**验收标准**:

- 消息加载正常
- 加载更多功能正常
- 错误处理完善

---

### 5. 消息输入和发送

#### 5.1 创建 ChatInput 组件

- [ ] 任务完成

**描述**: 创建消息输入组件

**子任务**:

- 创建 `src/pages/chat/components/ChatInput/index.tsx`
- 使用 Ant Design Input.TextArea 组件
- 实现自动高度调整（autoSize={{ minRows: 1, maxRows: 8 }}）
- 添加发送按钮（使用 teal 主题色 #14b8a6，图标 SendOutlined）
- 添加停止按钮（生成中显示，图标 StopOutlined）
- 布局：输入框 + 发送/停止按钮（右侧固定）
- 创建对应的 CSS Module 文件 `index.module.css`

**验收标准**:

- 输入框自动调整高度
- 按钮显示正确

---

#### 5.2 实现消息发送功能

- [ ] 任务完成

**描述**: 实现消息发送逻辑

**子任务**:

- 创建 `src/hooks/chat/useChatHandler.ts`
- 实现 sendMessage 函数（调用 `postChatSessionsIdMessages` API）
- 使用 React Query 的 useMutation
- 实现乐观更新（立即在 UI 中显示用户消息）
- 处理发送失败的回滚（移除乐观添加的消息）
- 发送成功后清空输入框
- 更新 chatStore 中的消息列表

**验收标准**:

- 消息发送正常
- 乐观更新生效
- 错误回滚正常

---

#### 5.3 实现快捷键支持

- [ ] 任务完成

**描述**: 实现键盘快捷键

**子任务**:

- 在 ChatInput 组件中监听键盘事件
- Enter 键发送消息（非 Shift+Enter）
- Shift+Enter 插入换行
- Ctrl+L 聚焦输入框（全局快捷键）
- 可选：创建 `src/hooks/chat/useKeyboardShortcuts.ts` 统一管理

**验收标准**:

- 快捷键功能正常
- 不影响正常输入

---

#### 5.4 实现消息编辑功能

- [ ] 任务完成

**描述**: 实现消息编辑功能

**子任务**:

- 在 Message 组件添加编辑按钮（EditOutlined，仅用户消息显示）
- 点击编辑时将消息内容加载到输入框
- 在 chatStore 中添加 editingMessageId 状态
- 实现 editMessage 函数（调用 API 删除该消息及之后的消息）
- 重新发送编辑后的消息
- 添加取消编辑按钮（在输入框上方显示编辑提示）

**验收标准**:

- 编辑功能正常
- 取消编辑正常

---

### 6. 滚动控制功能

#### 6.1 创建 ChatScrollButtons 组件

- [ ] 任务完成

**描述**: 创建滚动控制按钮组件

**子任务**:

- 创建 `src/pages/chat/components/ChatScrollButtons/index.tsx`
- 使用 Ant Design FloatButton.Group 组件
- 添加"滚动到顶部"按钮（UpOutlined 图标）
- 添加"滚动到底部"按钮（DownOutlined 图标）
- 固定在消息区域右下角
- 根据滚动位置动态显示/隐藏按钮
- 创建对应的 CSS Module 文件 `index.module.css`

**验收标准**:

- 按钮显示正确
- 动态显示/隐藏正常

---

#### 6.2 实现滚动控制逻辑

- [ ] 任务完成

**描述**: 实现滚动控制逻辑

**子任务**:

- 创建 `src/hooks/chat/useScroll.ts`
- 接收消息容器 ref 作为参数
- 监听滚动事件，更新按钮显示状态（距离顶部/底部 > 100px 时显示）
- 实现 scrollToTop 函数（使用 scrollTo({ top: 0, behavior: 'smooth' })）
- 实现 scrollToBottom 函数（使用 scrollTo({ top: scrollHeight, behavior: 'smooth' })）
- 新消息到达时自动滚动到底部（仅当用户在底部附近时）
- 使用 IntersectionObserver 监听底部元素，优化性能

**验收标准**:

- 滚动功能正常
- 自动滚动逻辑正确

---

### 7. 流式响应处理

#### 7.1 实现流式响应 Hook

- [ ] 任务完成

**描述**: 实现流式响应处理

**子任务**:

- 创建 `src/hooks/chat/useStreamResponse.ts`
- 调用 `getChat().postChatStream()` API 发送流式请求
- 使用 EventSource 或 fetch 的 ReadableStream 接收流式数据
- 实时更新消息内容（在 chatStore 中更新流式消息）
- 实现停止流式响应功能（调用 `postChatAbort` API）
- 处理流式响应错误（网络错误、解析错误等）
- 流式完成后标记消息为完成状态

**验收标准**:

- 流式响应正常
- 停止功能正常
- 错误处理完善

---

#### 7.2 集成流式响应到 ChatInput

- [ ] 任务完成

**描述**: 集成流式响应到输入组件

**子任务**:

- 在 useChatHandler 中集成 useStreamResponse
- 发送消息时启用流式响应（默认使用流式）
- 在消息列表中显示"正在生成"状态指示器（使用 Spin 或打字动画）
- 添加停止按钮（替换发送按钮，点击时调用 stopStream）
- 流式完成后保存完整消息到数据库
- 更新 chatStore 的 isGenerating 状态

**验收标准**:

- 流式响应集成正常
- 状态指示器显示正确
- 停止按钮功能正常

---

### 8. 文件上传功能（可选）

#### 8.1 创建 FilePicker 组件

- [ ] 任务完成（可选）

**描述**: 创建文件选择组件

**子任务**:

- 创建 `src/pages/chat/components/FilePicker/index.tsx`
- 添加文件选择按钮（使用 Ant Design Upload 组件）
- 实现文件拖拽上传（Upload 的 dragger 模式）
- 显示文件预览（图片显示缩略图，其他文件显示图标和名称）
- 允许移除已选文件（Upload 的 onRemove 回调）
- 创建对应的 CSS Module 文件 `index.module.css`

**验收标准**:

- 文件选择功能正常
- 拖拽上传正常
- 文件预览显示正确

---

#### 8.2 实现文件上传逻辑

- [ ] 任务完成（可选）

**描述**: 实现文件上传处理逻辑

**子任务**:

- 创建 `src/hooks/chat/useFileHandler.ts`
- 实现文件类型验证（白名单：图片、PDF、文本等）
- 实现文件大小验证（单文件最大 10MB）
- 实现文件上传 API（如果后端支持，否则转为 base64）
- 跟踪上传进度（使用 Upload 的 progress 属性）
- 支持多文件上传（最多 5 个文件）

**验收标准**:

- 文件验证正常
- 上传功能正常
- 进度显示正确

---

#### 8.3 实现图片粘贴功能

- [ ] 任务完成（可选）

**描述**: 实现图片粘贴功能

**子任务**:

- 在 ChatInput 组件中监听 paste 事件
- 检测并提取图片数据（从 clipboard.items）
- 显示图片预览（在输入框上方）
- 验证模型是否支持图片输入（检查当前模型配置）
- 转换图片为 base64 格式（使用 FileReader）
- 发送消息时将图片数据包含在请求中

**验收标准**:

- 粘贴图片功能正常
- 图片预览显示正确
- 图片发送正常

---

### 9. 聊天设置功能

#### 9.1 创建 ChatSettings 组件

- [ ] 任务完成

**描述**: 创建聊天设置组件

**子任务**:

- 创建 `src/pages/chat/components/ChatSettings/index.tsx`
- 使用 Ant Design Drawer 组件（从右侧滑出，宽度 400px）
- 添加模型选择器（使用 Select，从 providers API 获取模型列表）
- 添加温度参数滑块（Slider，范围 0-2，步长 0.1）
- 添加 TopP 参数滑块（Slider，范围 0-1，步长 0.1）
- 添加系统提示词文本框（TextArea，支持多行）
- 使用 Ant Design Form 组件管理表单状态
- 创建对应的 CSS Module 文件 `index.module.css`

**验收标准**:

- 设置面板显示正确
- 所有设置项可交互

---

#### 9.2 实现设置保存功能

- [ ] 任务完成

**描述**: 实现设置保存逻辑

**子任务**:

- 使用 lodash.debounce 实现防抖保存（延迟 500ms）
- 调用 `patchChatSessionsId` API 更新会话设置
- 使用 React Query 的 useMutation 处理更新
- 更新 chatStore 中的当前会话设置
- 显示保存成功提示（使用 Ant Design message）
- 处理保存失败的错误提示

**验收标准**:

- 设置保存正常
- 防抖生效
- 提示信息正确

---

### 10. 助手和工具选择（可选功能）

#### 10.1 创建 AssistantPicker 组件

- [ ] 任务完成（可选）

**描述**: 创建助手选择组件

**子任务**:

- 创建 `src/pages/chat/components/AssistantPicker/index.tsx`
- 使用 Ant Design Select 组件实现助手选择器
- 从后端 API 获取助手列表（如果有相关 API）
- 显示当前选中的助手信息（名称、描述）
- 支持切换助手（更新会话配置）
- 在输入框上方显示当前助手标签

**验收标准**:

- 助手选择功能正常
- 助手信息显示正确

---

#### 10.2 创建 ToolPicker 组件

- [ ] 任务完成（可选）

**描述**: 创建工具选择组件

**子任务**:

- 创建 `src/pages/chat/components/ToolPicker/index.tsx`
- 使用 Ant Design Select 组件（mode="multiple"）实现工具选择器
- 从后端 API 获取可用工具列表（如果有相关 API）
- 显示已选工具标签（使用 Tag 组件）
- 支持添加/移除工具（点击标签关闭按钮移除）
- 在输入框上方显示已选工具

**验收标准**:

- 工具选择功能正常
- 工具标签显示正确

---

### 11. 性能优化

#### 11.1 实现虚拟滚动

- [ ] 任务完成（可选）

**描述**: 实现虚拟滚动优化

**子任务**:

- 安装 `react-window`：`yarn add react-window @types/react-window`
- 在 ChatMessages 组件中集成 VariableSizeList
- 仅在消息数量 > 100 时启用虚拟滚动
- 计算每条消息的动态高度
- 保持滚动位置在加载更多消息时的稳定性

**验收标准**:

- 虚拟滚动正常
- 性能提升明显

---

#### 11.2 实现组件优化

- [ ] 任务完成

**描述**: 优化组件性能

**子任务**:

- 使用 React.memo 优化 Message 组件（避免不必要的重渲染）
- 使用 React.memo 优化 SessionItem 组件
- 使用 useMemo 缓存消息分组计算结果
- 使用 useCallback 优化事件处理函数（sendMessage、editMessage 等）
- 在 MessageMarkdown 中使用 useMemo 缓存渲染结果

**验收标准**:

- 组件重渲染减少
- 性能提升明显

---

#### 11.3 实现代码分割

- [ ] 任务完成

**描述**: 实现代码分割优化

**子任务**:

- 使用 React.lazy 懒加载 ChatSettings 组件
- 使用 React.lazy 懒加载 MessageMarkdown 组件
- 使用 React.lazy 懒加载 MessageCodeBlock 组件
- 添加 Suspense 边界（使用 Ant Design Spin 作为 fallback）
- 在路由层面懒加载 ChatPage 组件

**验收标准**:

- 代码分割生效
- 首屏加载速度提升

---

### 12. 错误处理和加载状态

#### 12.1 实现全局错误处理

- [ ] 任务完成

**描述**: 实现统一错误处理

**子任务**:

- 在 `src/types/chat.ts` 中创建错误类型枚举（ChatErrorType）
- 创建 `src/utils/chatErrorHandler.ts` 实现统一的错误处理函数
- 使用 Ant Design message 显示用户友好的错误提示
- 实现重试机制（React Query 默认重试 3 次）
- 处理特定错误：网络错误、会话不存在、权限错误等

**验收标准**:

- 错误处理完善
- 错误提示友好

---

#### 12.2 优化加载状态

- [ ] 任务完成

**描述**: 优化加载状态显示

**子任务**:

- 页面初始加载显示全屏 Spin（在 ChatPage 组件中）
- 消息发送中显示输入框加载状态（禁用输入框，显示 loading 图标）
- 历史消息加载显示顶部加载指示器（在消息列表顶部显示小型 Spin）
- 会话列表加载显示骨架屏（使用 Ant Design Skeleton）
- 实现平滑过渡动画（使用 CSS transition）

**验收标准**:

- 加载状态显示正确
- 过渡动画流畅

---

### 13. 样式和主题

#### 13.1 应用 teal 主题色

- [ ] 任务完成

**描述**: 应用统一主题色

**子任务**:

- 在各组件的 CSS Module 中定义 teal 主题色变量（--chat-primary: #14b8a6）
- 应用到用户消息背景（Message 组件）
- 应用到发送按钮（ChatInput 组件）
- 应用到会话选中状态（SessionItem 组件）
- 应用到输入框聚焦状态（ChatInput 组件）
- 应用到 ChatHeader 标题区域

**验收标准**:

- 主题色应用一致
- 视觉效果统一

---

#### 13.2 实现响应式样式

- [ ] 任务完成

**描述**: 实现响应式布局

**子任务**:

- 桌面端（> 768px）：左侧栏 280px，主内容区自适应
- 移动端（< 768px）：左侧栏收起为 Drawer，主内容区全屏
- 使用 CSS 媒体查询调整布局
- 调整按钮大小和间距（移动端更大的触摸区域）
- 确保所有屏幕尺寸下文字可读（最小字号 14px）
- 测试不同设备和屏幕尺寸

**验收标准**:

- 响应式布局正常
- 移动端体验良好

---

### 14. 可访问性和安全

#### 14.1 实现键盘导航

- [ ] 任务完成

**描述**: 实现键盘导航支持

**子任务**:

- 确保 Tab 键可以在所有交互元素间导航
- 为所有按钮添加 aria-label（发送按钮、编辑按钮、删除按钮等）
- 消息列表容器使用 role="log" 和 aria-live="polite"
- 加载状态使用 aria-busy="true"
- 输入框添加 aria-label="消息输入框"
- 测试键盘导航的完整性

**验收标准**:

- 键盘导航完整
- 无障碍属性正确

---

#### 14.2 实现 XSS 防护

- [ ] 任务完成

**描述**: 实现安全防护

**子任务**:

- 配置 react-markdown 安全模式（disallowedElements: ['script', 'iframe']）
- 禁止 HTML 标签（使用 remarkGfm 插件，不使用 rehypeRaw）
- 外部链接添加 rel="noopener noreferrer" target="_blank"
- 用户输入在显示前自动转义（React 默认行为）
- 代码块内容使用 textContent 而非 innerHTML

**验收标准**:

- XSS 防护生效
- 安全配置正确

---

### 15. 测试和文档

#### 15.1 编写单元测试

- [ ] 任务完成（可选）

**描述**: 编写单元测试

**子任务**:

- 测试 useChatHandler hook（使用 @testing-library/react-hooks）
- 测试 useScroll hook（模拟滚动事件）
- 测试 Message 组件（渲染、交互）
- 测试 ChatInput 组件（输入、发送、快捷键）
- 测试 SessionItem 组件（显示、操作按钮）
- 使用 Vitest 运行测试

**验收标准**:

- 测试覆盖率 > 80%
- 所有测试通过

---

#### 15.2 编写集成测试

- [ ] 任务完成（可选）

**描述**: 编写集成测试

**子任务**:

- 测试消息发送流程（输入 -> 发送 -> 显示）
- 测试文件上传流程（选择 -> 上传 -> 显示）
- 测试流式响应（发送 -> 流式接收 -> 完成）
- 测试会话切换流程
- 使用 React Testing Library

**验收标准**:

- 主要流程测试通过
- 集成测试稳定

---

#### 15.3 创建功能文档

- [ ] 任务完成（可选）

**描述**: 创建功能文档

**子任务**:

- 在 `docs/chat-sessions-page/` 创建 README.md
- 记录组件使用方法和 Props 说明
- 记录 API 调用方式和参数说明
- 记录已知问题和限制
- 添加使用示例和截图
- 记录性能优化建议

**验收标准**:

- 文档完整清晰
- 示例可运行

---

### 16. RAG 支持（可选功能）

#### 16.1 实现检索增强生成

- [ ] 任务完成（可选）

**描述**: 实现 RAG 功能

**子任务**:

- 检测会话是否包含文件（检查 session.meta.files）
- 自动启用检索功能（在发送消息时添加 retrieval 参数）
- 从文件中检索相关内容（调用检索 API）
- 在回复中标注引用来源（显示引用的文件名和片段）
- 支持配置检索文档数量（在 ChatSettings 中添加配置项）
- 显示检索到的文档片段（在消息下方展开显示）

**验收标准**:

- RAG 功能正常
- 引用来源显示正确

---

## 实现优先级

### P0 - 核心功能（必须实现）

**基础设施和界面**:

- 任务 1：项目基础设施搭建
- 任务 2：会话列表功能实现
- 任务 3：聊天界面核心组件
- 任务 4：消息展示功能
- 任务 5：消息输入和发送
- 任务 6：滚动控制功能
- 任务 7：流式响应处理

**设置和优化**:

- 任务 9：聊天设置功能
- 任务 11.2：组件优化
- 任务 12：错误处理和加载状态
- 任务 13：样式和主题
- 任务 14：可访问性和安全

### P1 - 增强功能（建议实现）

- 任务 11.3：代码分割

### P2 - 可选功能

**扩展功能**:

- 任务 8：文件上传功能
- 任务 10：助手和工具选择
- 任务 11.1：虚拟滚动
- 任务 16：RAG 支持

**质量保证**:

- 任务 15：测试和文档

---

## 技术规范

### 技术栈

- **框架**: React 18.3 + TypeScript 5.8
- **UI 库**: Ant Design 5.25
- **状态管理**: Zustand + React Query (TanStack Query)
- **样式方案**: TailwindCSS 4.1 + CSS Modules
- **Markdown**: react-markdown + remark-gfm + rehype-highlight
- **代码高亮**: highlight.js

### 开发规范

- 遵循项目的 TypeScript 严格模式
- 所有用户可见文本使用中文
- 代码注释使用中文
- 使用路径别名 `@/` 引用 src 目录
- 组件文件使用 PascalCase 命名
- 优先使用函数式组件和 React Hooks

### 样式规范

- 主题色：teal (#14b8a6)
- 用户消息：teal 背景，白色文字，右对齐
- AI 消息：灰色背景 (#f3f4f6)，黑色文字，左对齐
- 会话列表宽度：280px（可折叠）
- 响应式断点：768px

### API 使用

- API 层已生成：`src/services/api/sessions/sessions.ts` 和 `src/services/api/messages/messages.ts`
- 使用 React Query 进行数据获取和状态管理
- 使用 Zustand 管理全局聊天状态
- 所有 API 调用使用 useMutation 或 useQuery

### 性能要求

- 使用 React.memo 优化组件
- 使用 useMemo 和 useCallback 优化计算和回调
- 消息数量 > 100 时考虑虚拟滚动
- 使用 React.lazy 和 Suspense 进行代码分割
- 使用 IntersectionObserver 优化滚动监听

### 安全要求

- 配置 react-markdown 安全模式
- 禁止 HTML 标签渲染
- 外部链接添加安全属性
- 用户输入自动转义
- 代码块使用 textContent

---

## 注意事项

1. **任务独立性**: 每个任务都应该是独立可测试的
2. **模板参考**: 实现时参考 `模板规范.md` 中的代码模板
3. **类型安全**: 确保类型安全，避免使用 `any`
4. **错误处理**: 所有 API 调用都需要错误处理
5. **加载状态**: 所有异步操作都需要加载状态
6. **可访问性**: 确保键盘导航和屏幕阅读器支持
7. **响应式**: 确保移动端和桌面端体验良好
8. **性能**: 注意大量消息时的性能优化

---

## 开始实现

建议按照以下顺序实现：

1. **第一阶段**：完成任务 1-3（基础设施和界面框架）
2. **第二阶段**：完成任务 4-5（消息展示和输入）
3. **第三阶段**：完成任务 6-7（滚动和流式响应）
4. **第四阶段**：完成任务 9、11.2、12-14（设置、优化、错误处理、样式）
5. **第五阶段**：根据需要实现可选功能（任务 8、10、11.1、15、16）
